public class Amigos extends Pessoa{
	private int convite;
	private String email;
	private String usuario;
	private Data dataNasc;

	
	public Amigos(String nome, String usuario, int sexo, int convite, String email, Data dataNasc){
		super(nome, sexo, dataNasc);
		this.email=email;
		this.usuario=usuario;
		this.dataNasc=dataNasc;
	}
	public int getConvite() {
		return convite;
	}
	public void setConvite(int convite) {
		this.convite = convite;
	}
	public Data getDataNasc() {
		return dataNasc;
	}
	public void setDataNasc(Data dataNasc) {
		this.dataNasc = dataNasc;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	
	
}
