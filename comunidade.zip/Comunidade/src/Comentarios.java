public class Comentarios extends Post{

	public Comentarios(Usuario user) {
		super(user);
	}

}
