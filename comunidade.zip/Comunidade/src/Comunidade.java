import java.util.ArrayList;


public class Comunidade {
	private String nome;
	private String usuario;
	private ArrayList<Amigos> amigos;

	public Comunidade(String nome, String usuario) {
		this.amigos= new ArrayList<Amigos>();
		this.nome=nome;
		this.usuario=usuario;
	}
	//GETTERS AND SETTERS
	public ArrayList<Amigos> getMembros() {
		return amigos;
	}

	public void setMembros(ArrayList<Amigos> membros) {
		this.amigos = membros;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public ArrayList<Amigos> getAmigos() {
		return amigos;
	}
	public void setAmigos(ArrayList<Amigos> amigos) {
		this.amigos = amigos;
	}
	@Override
	public String toString() {
		return "Usuario [Nome da Comunidade=" + this.getNome()+"; Numero de Membros: "+this.getMembros().size()+"]";
	}
	
}
