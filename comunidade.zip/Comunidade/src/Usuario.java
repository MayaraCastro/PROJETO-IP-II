import java.util.ArrayList;

public class Usuario extends Pessoa{
	
	private String usuario;
	private String senha;
	private String email;
	private Data dataNasc;
	private ArrayList<Atividade> atividades;
	private ArrayList<Task> tasks;
	private ArrayList<Amigo> amigos;
	private ArrayList<Amigo> amigosPendentes;
	private ArrayList<Comunidade> comunidade;
	private ArrayList<Post> postagem;

	public Usuario(String nome, String usuario, String senha, int sexo, String email, Data dataNasc) {
		super(nome,sexo);
		
		this.usuario = usuario;
		this.senha = senha;
		this.email = email;
		this.dataNasc=dataNasc;
		
		this.atividades = new ArrayList<Atividade>();
		this.tasks = new ArrayList<Task>();
		this.amigos= new ArrayList<Amigo>();
		this.amigosPendentes= new ArrayList<Amigo>();

	}
	
	//METODO PARA ADICIONAR AMIGO
	public boolean addAmigo(Amigo amg){
		if(!this.amigos.contains(amg)){
			if(this.amigosPendentes.contains(amg) && amg.getConvite() == 1){ 
				this.amigos.add(amg);
				this.amigosPendentes.remove(amg);	
			}
			else{
				this.amigosPendentes.add(amg);
			}
			return true;
		}
		return false;
	}
	public boolean delAmigo(Amigo amg){
		if(!this.amigos.contains(amg)){
			if(this.amigosPendentes.contains(amg)){
				this.amigosPendentes.remove(amg);
				return true;	
			}
		}
		else{
			this.amigos.remove(amg);
			return(true);
		}
		return false;
	}
	//MANUPULAÇÃO PARA ADICIONAR Comunidade
		public boolean addComunidade(Comunidade cmd){
			if(!this.amigos.contains(cmd)){
				this.amigos.add(cmd);
				return true;
			}
			return false;
		}
		public boolean delComunidade(Comunidade cmd){
			if(this.amigos.contains(cmd)){
				this.amigos.remove(cmd);
				return(true);
			}
			return false;
		}
	//MANIPULAÇÃO DE POST
	public boolean addpOST(Post post){
			if(!this.postagem.contains(post)){
					this.postagem.add(post);
				return true;
			}
			return false;
		}
	public boolean delPost(Post post){
			if(!this.postagem.contains(post)){
				this.postagem.remove(post);
				return(true);
			}
			return false;
	}
	
	//GETTERS AND SETTERS
	public ArrayList<Atividade> getAtividades() {
		return atividades;
	}
	public void setAtividades(ArrayList<Atividade> atividades) {
		this.atividades = atividades;
	}
	public ArrayList<Task> getTasks() {
		return tasks;
	}
	public void setTasks(ArrayList<Task> tasks) {
		this.tasks = tasks;

	}
	
	
	public Data getDataNasc() {
		return dataNasc;
	}

	public void setDataNasc(Data dataNasc) {
		this.dataNasc = dataNasc;
	}

	public String getUsuario() {
		return usuario;
	}


	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}


	public String getSenha() {
		return senha;
	}


	public void setSenha(String senha) {
		this.senha = senha;
	}

	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}
	
	public ArrayList<Amigo> getAmigos() {
		return amigos;
	}
	public void setAmigos(ArrayList<Amigo> amigos) {
		this.amigos = amigos;
	}
	public ArrayList<Amigo> getAmigosPendentes() {
		return amigosPendentes;
	}
	public void setAmigosPendentes(ArrayList<Amigo> amigosPendentes) {
		this.amigosPendentes = amigosPendentes;
	}	
	public ArrayList<Comunidade> getComunidade() {
		return comunidade;
	}

	public void setComunidade(ArrayList<Comunidade> comunidade) {
		this.comunidade = comunidade;
	}

	@Override
	public String toString() {
		return "Usuario [nome=" + this.getNome()+ ", usuario=" + usuario + ", senha=" + senha
				+ ", sexo=" + this.getSexo() + ", email=" + email+"]";
	}


	
}
