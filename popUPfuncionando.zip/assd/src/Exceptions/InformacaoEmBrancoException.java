package Exceptions;

public class InformacaoEmBrancoException extends Exception {

	public InformacaoEmBrancoException() {
		super("� preciso preencher todos as informa��es");
	}
	
	
}
