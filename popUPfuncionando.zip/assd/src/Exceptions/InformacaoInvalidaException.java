package Exceptions;

public class InformacaoInvalidaException extends Exception{

	public InformacaoInvalidaException() {
		super("Informacao dada invalida");
	}

}
