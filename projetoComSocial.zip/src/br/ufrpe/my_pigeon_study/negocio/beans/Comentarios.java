package br.ufrpe.my_pigeon_study.negocio.beans;

public class Comentarios extends Post{

	public Comentarios(Usuario user) {
		super(user);
	}

}
