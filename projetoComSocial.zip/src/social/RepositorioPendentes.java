package social;

public class RepositorioPendentes {

}
